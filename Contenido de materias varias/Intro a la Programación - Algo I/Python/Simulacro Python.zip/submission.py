from queue import Queue as Cola

# Ejercicio 1
def gestion_notas(notas_estudiante_materia: list[tuple[str, str, int]]) -> dict[str, list[tuple[str,int]]]:
    
    res = {}
    for i in range(len(notas_estudiante_materia)):
        
        estudiante: str = notas_estudiante_materia[i][0]
        materia: str = notas_estudiante_materia[i][1]
        nota: int = notas_estudiante_materia[i][2]
        
        if not pertenece(estudiante, res):
            res[estudiante] = [(materia, nota)]
        else:
            res[estudiante].append((materia, nota))

    return res

def pertenece(estudiante: str, dic: dict) -> bool:
    res: bool = False
    for key in dic.keys():
        if estudiante == key: 
            res = True
            break
    return res

# En pertenece(), no es estrictamente necesario usar 'break',
# pero innecesario también seguir recorriendo la lista si ya
# se cumplió la condición para que res sea True
 
##################################################

##################################################

# Ejercicio 2
def cantidad_digitos_pares(numeros: list[int]) -> int:
    
    res: int = 0

    for num in numeros:
        for digit in str(num):
            if int(digit)%2 == 0: res+=1
    
    return res

##################################################

##################################################

# Ejercicio 3
def reordenar_cola_primero_pesados(paquetes: Cola[tuple[str,int]], umbral:int) -> Cola[tuple[str,int]]:
    
    q_aux: Cola[tuple[str, int]] = Cola()

    mayores: list[tuple[str,int]] = []
    menores: list[tuple[str,int]] = []

    while not paquetes.empty():

        paquete: tuple[str,int] = paquetes.get()

        peso: int = paquete[1]

        if peso > umbral:
            mayores.append(paquete)
        else:
            menores.append(paquete)
        
        # Ahora quiero rearmar la cola de return:
        # Agrego uno a uno los elementos de las listas (1° mayores, despues menores).

    for i in range(len(mayores)):
        q_aux.put(mayores[i])
    
    for i in range(len(menores)):
        q_aux.put(menores[i])

    # print(mayores, '\n-----\n', menores, '\n-----\n')

    return q_aux

def leer_cola(cola: Cola[tuple[str,int]]):
    aux: Cola = Cola()
    
    while not cola.empty():
        elem = cola.get()
        print(elem, '\n---\n')
        aux.put(elem)

    while not aux.empty():
        cola.put(aux.get())

##################################################

##################################################

# Ejercicio 4
def matriz_pseudo_ordenada(matriz: list[list[int]]) -> bool:
    
    cant_filas: int = len(matriz)
    cant_columnas: int = len(matriz[0])

    columnas: list[list[int]] = []
    for m in range(cant_columnas):
        col: list[int] = []
        for n in range(cant_filas):
            col.append(matriz[n][m])
        columnas.append(col)

    print(columnas)

    res: bool = True
    for i in range(cant_columnas-1):
        if minimo(columnas[i]) > minimo(columnas[i+1]):
            res = False
    
    return res


def minimo(lista: list[int]) -> int:

    minimo: int = lista[0]
    for i in range(len(lista)):
        if lista[i] < minimo:
            minimo = lista[i]

    return minimo
