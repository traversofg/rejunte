module SolucionT1 where


-- Ejercicio 1
maxMovilN :: [Integer] -> Integer -> Integer
maxMovilN lista n = maximo (ultimosN lista n)

maximo :: [Integer] -> Integer
maximo (x:[]) = x
maximo (x1:x2:xs)
    | x1 > x2 = maximo (x1:xs)
    | otherwise = maximo (x2:xs)

ultimosN :: [Integer] -> Integer -> [Integer]
ultimosN [] _ = []
ultimosN _ 0 = []
ultimosN (x1:xs) n
 | longitud xs == n = xs
 | otherwise = ultimosN xs n

longitud :: [Integer] -> Integer
longitud [] = 0
longitud (x:xs) = 1 + longitud xs 

{-
-- Test Ejercicio 1
listaParaTest :: [Integer]
listaParaTest = [1,4,2,2,234,4,1,13,9,2,1]

testEjercicioUno :: [Integer] -> Integer -> Integer
testEjercicioUno _ n = maxMovilN listaParaTest n
-}

-- Ejercicio 2
promedioPrimo :: Integer -> Float
promedioPrimo n = 
    sumaTotal / cantFactores
    where 
        sumaTotal = fromIntegral((sumaElementos factN))
        cantFactores = fromIntegral((longitud factN))
        factN = factoresPrimos n

sumaElementos :: [Integer] -> Integer
sumaElementos [] = 0
sumaElementos (x:xs) = x + sumaElementos xs

factoresPrimos :: Integer -> [Integer]
factoresPrimos n = factoresPrimosAux n nrosPrimos

factoresPrimosAux :: Integer -> [Integer] -> [Integer]
factoresPrimosAux 1 _ = []
factoresPrimosAux n (p1:ps) 
    | mod n p1 == 0 = p1 : factoresPrimosAux (div n p1) (p1:ps)
    | otherwise = factoresPrimosAux n ps

{-  Comentario por si revisan el examen:

    Probablemente sea increiblemente chanta hacer
esta lista de los primeros numeros primos, pero
no creo que me de el tiempo para hacer una mas
interesante.
    Por las dudas me fije y multiplicando los
ultimos 4 elementos el resultado es 1.297.257,
y dudo mucho que no alcance con esa factorizacion
-}

nrosPrimos = [2,3,5,7,11,13,17,19,23,29,31,37]
                

-- Ejercicio 3
letrasIguales :: String -> Integer
letrasIguales z = letrasIgualesAux (quitarTodo ' ' z)

letrasIgualesAux :: String -> Integer
letrasIgualesAux [] = 0
letrasIgualesAux (char1:[]) = 0
letrasIgualesAux (p1:ps)
    | (contarApariciones p1 ps) > 0 = 1 + pasoRecursivo
    | otherwise = pasoRecursivo
    where pasoRecursivo = letrasIgualesAux (quitarTodo p1 ps)

contarApariciones :: Char -> String -> Integer
contarApariciones _ [] = 0
contarApariciones char (p:ps)
    | char == p = 1 + pasoRecursivo
    | otherwise = pasoRecursivo
    where pasoRecursivo = contarApariciones char ps
        
quitarTodo :: (Eq a) => a -> [a] -> [a]
quitarTodo _ [] = []
quitarTodo a (x:xs)
    | a == x = pasoRecursivo
    | otherwise = x : pasoRecursivo
    where pasoRecursivo = quitarTodo a xs


-- Ejercicio 4
cuantosIguales :: String -> String -> Integer
cuantosIguales palabra1 palabra2 = 
    cuantosAux palUnoMod palDosMod
    where
        palUnoMod = quitarTodo ' ' palabra1
        palDosMod = quitarTodo ' ' palabra2


cuantosAux :: String -> String -> Integer
cuantosAux pal1 pal2 = 
    longitudString ( eliminarRepeticiones ( compararEntrePalabras pal1 pal2 ) )
    where
        p1 = eliminarRepeticiones pal1
        p2 = eliminarRepeticiones pal2

eliminarRepeticiones :: String -> String -- o [Char]
eliminarRepeticiones [] = []
eliminarRepeticiones (p1:ps) = 
    (p1 : eliminarRepeticiones restoChar)
    where restoChar = quitarTodo p1 ps

{- Quiero una funcion aux que agarre dos palabras y me devuelva
un String con los caracteres que aparecen en ambas palabras;
no me importa si se repiten o que, el unico requisito es que
el caracter que termina en la lista final se encuentre en las
las dos palabras.
-}
compararEntrePalabras :: String -> String -> String 
compararEntrePalabras _ [] = []
compararEntrePalabras [] _ = []
compararEntrePalabras (a1:as) (b1:bs)

    | a1 == b1 =
        a1 : pasoRecursivo

    | ( a1 /= b1 ) && ( contarApariciones a1 (b1:bs) > 0 ) =
        a1 : compararEntrePalabras as (b1:bs)

    | ( a1 /= b1 ) && ( contarApariciones b1 (a1:as) > 0 ) =
        b1 : compararEntrePalabras (a1:as) bs
    
    | otherwise = pasoRecursivo

    where pasoRecursivo = compararEntrePalabras as bs

longitudString :: String -> Integer
longitudString [] = 0
longitudString (p1:ps) = 1 + longitudString ps


{-
-- Para testear

palabraUno = "hola che"
palabraDos = "che hola"
palabraTres = "esto es un test"

testEjCuatroUno = cuantosIguales palabraUno palabraDos -- h, o, l, a, c, e --> 6 

testEjCuatroDos = cuantosIguales palabraUno palabraTres -- e , o --> 2

testEjCuatroTres = cuantosIguales palabraDos palabraTres -- e, o --> 2
-}